Stupid cludge to cover some SUMS site JEvents until I get access to that code!

Michael 20110224